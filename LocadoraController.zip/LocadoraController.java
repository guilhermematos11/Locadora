package br.ucsal.locadora.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.ucsal.locadora.DTO.LocadoraDTO;
import br.ucsal.locadora.Entity.Locadora;
import br.ucsal.locadora.Service.LocadoraService;

@RestController
@RequestMapping("/Locadoras")
public class LocadoraController {

	@Autowired
	private LocadoraService LocadoraService;
	
	@PostMapping("/create")
    private Locadora create(LocadoraDTO LocadoraDTO) {
        return LocadoraService.create(LocadoraDTO);
    }

	@PostMapping("/update")
    private Locadora update(LocadoraDTO LocadoraDTO) {
        return LocadoraService.update(LocadoraDTO);
    }
   
	@GetMapping("/todos")
	public List<Locadora> todos() {
		return LocadoraService.todos();
	}
 
}