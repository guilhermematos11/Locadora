package br.ucsal.locadora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class locadoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(locadoraApplication.class, args);
	}

}
