package br.ucsal.locadora.Entity;

public  enum Unidade {
	BADBOYS, GLADIADOR, AVATAR, FURIOSA, MOANA;
}
