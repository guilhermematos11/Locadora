package br.ucsal.locadora.DTO;

import br.ucsal.locadora.Entity.Unidade;

public record LocadoraDTO(Long id, String sigla,String descricao, Unidade unidade) {


}