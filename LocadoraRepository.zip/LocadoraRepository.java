package br.ucsal.locadora.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.ucsal.locadora.Entity.Locadora;

@Repository
public interface LocadoraRepository  extends JpaRepository<Locadora, Long> {

}