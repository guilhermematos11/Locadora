package br.ucsal.locadora.Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.ucsal.locadora.DTO.LocadoraDTO;
import br.ucsal.locadora.Entity.Locadora;
import br.ucsal.locadora.Repository.LocadoraRepository;

@Service
public class LocadoraService {

	@Autowired
	private LocadoraRepository LocadoraRepository;
	
	public Locadora create(LocadoraDTO dto) {
		return LocadoraRepository.save(new Locadora(dto));
	}
	
	public Locadora update(LocadoraDTO dto) {
		return LocadoraRepository.save(new Locadora(dto));
	}
	
	public List<Locadora> todos() {
		return LocadoraRepository.findAll();
	}
} 